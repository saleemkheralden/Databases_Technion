DROP VIEW CompaniesInIndus
DROP VIEW improvingCompany
DROP VIEW improvingCompanySymbol
DROP VIEW indusCountry
DROP VIEW maxStocks



